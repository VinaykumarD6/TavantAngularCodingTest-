import { Component, Input, OnInit } from '@angular/core';
import { AddExperience } from 'src/app/profile-forms/models/add-experience';

@Component({
  selector: 'app-experience-item',
  templateUrl: './experience-item.component.html',
  styleUrls: ['./experience-item.component.css']
})
export class ExperienceItemComponent implements OnInit {

  @Input() experience : AddExperience;  
  constructor() { }
  ngOnInit(): void {
  }

}

import { Component, Input, OnInit } from '@angular/core';
import { AddEducation } from 'src/app/profile-forms/models/add-education';

@Component({
  selector: 'app-education-item',
  templateUrl: './education-item.component.html',
  styleUrls: ['./education-item.component.css']
})
export class EducationItemComponent implements OnInit {
  @Input() education : AddEducation;  

  constructor() { }

  ngOnInit(): void {
  }

}

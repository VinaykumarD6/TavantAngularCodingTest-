import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { DashboardActionsComponent } from './components/dashboard-actions/dashboard-actions.component';
import { EducationComponent } from './components/education/education.component';
import { ExperienceComponent } from './components/experience/experience.component';
import { EditProfileComponent } from '../profile-forms/components/edit-profile/edit-profile.component';
import { EducationItemComponent } from './components/education-item/education-item.component';
import { ComponentsComponent } from './components/components.component';
import { ExperienceItemComponent } from './components/experience-item/experience-item.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { AuthService } from '../auth/services/auth.service';

@NgModule({
  declarations: [
    DashboardComponent,
    DashboardActionsComponent,
    EducationComponent,
    ExperienceComponent,
    EducationItemComponent,
    ComponentsComponent,
    ExperienceItemComponent,
  ],
  imports: [CommonModule, HttpClientModule, DashboardRoutingModule],
  providers: [HttpClient, AuthService],
})
export class DashboardModule {}

import { EditProfile } from './edit-profile';

describe('EditProfile', () => {
  it('should create an instance', () => {
    expect(new EditProfile()).toBeTruthy();
  });
});
